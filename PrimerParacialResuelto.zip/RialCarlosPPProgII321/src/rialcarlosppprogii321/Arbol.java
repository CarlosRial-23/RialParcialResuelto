package rialcarlosppprogii321;

public class Arbol extends Planta{

    private int alturaMaxima;

    public Arbol(String nombre, String ubicacionJardin, String clima, int alturaMaxima) {
        super(nombre, ubicacionJardin, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public String toString() {
        return "Arbol{alturaMaxima=" + alturaMaxima + super.toString() + '}';
    }
    
    
    
    

}
