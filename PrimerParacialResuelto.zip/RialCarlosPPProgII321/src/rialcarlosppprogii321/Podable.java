package rialcarlosppprogii321;

public interface Podable {
    
    public void podar();
    
}
