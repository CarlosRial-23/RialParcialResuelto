package rialcarlosppprogii321;

public class FlorNoPuedenPodarException extends RuntimeException{

    private static final String MESSAGE = "Soy una Flor, no necesito ser podada";

    public FlorNoPuedenPodarException() {
        super(MESSAGE);
    }
    
}
