package rialcarlosppprogii321;

public class Arbusto extends Planta implements Podable{

    private static final int MIN_DENSIDAD = 1;
    private static final int MAX_DENSIDAD = 10;
    private int densidad;

    public Arbusto(String nombre, String ubicacionJardin, String clima, int densidad){
        super(nombre, ubicacionJardin, clima);
        setDensidad(densidad);
    }

    public void setDensidad(int densidad) {
        if(densidad < MIN_DENSIDAD || densidad > MAX_DENSIDAD){
            throw new IllegalArgumentException("ERROR.Densidad invalida");
        }
        this.densidad = densidad;
    }

    @Override
    public String toString() {
        return "Arbusto{" + super.toString() + " densidad=" + densidad + '}';
    }
    
    @Override
    public void podar() {
        System.out.println(this.getNombre() + " y me estan podando...");
    }
    
    
    
    

}
