package rialcarlosppprogii321;

import java.util.Objects;

public abstract class Planta {

    private String nombre;
    private String ubicacionJardin;
    private String clima;

    public Planta(String nombre, String ubicacionJardin, String clima) {
        this.nombre = nombre;
        this.ubicacionJardin = ubicacionJardin;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Planta)) {
            return false;
        }
        
        final Planta other = (Planta) obj;
        return ubicacionJardin.equals(other.ubicacionJardin) && nombre.equals(other.nombre);
    }
    
    
    
    @Override
    public int hashCode(){
       return Objects.hash(nombre,ubicacionJardin);
    }

    @Override
    public String toString() {
        return  ", nombre=" + nombre + ", ubicacionJardin=" + ubicacionJardin + ", clima=" + clima;
    }
    
    
    
    

}
