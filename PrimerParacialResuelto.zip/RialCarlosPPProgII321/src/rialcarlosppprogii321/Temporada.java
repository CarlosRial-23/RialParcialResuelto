package rialcarlosppprogii321;

public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO
}
